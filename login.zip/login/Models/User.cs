﻿using System.ComponentModel.DataAnnotations;

namespace login.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }

        public ICollection<Product> products { get; set; }= new HashSet<Product>();
    }
}
