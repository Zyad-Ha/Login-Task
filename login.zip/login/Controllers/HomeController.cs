using System.Diagnostics;
using login.data;
using login.Models;
using Microsoft.AspNetCore.Mvc;

namespace login.Controllers
{
    public class HomeController : Controller
    {
        public static int username;
        private readonly Context _context;
        public HomeController(Context context )
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                _context.users.Add(user);
                _context.SaveChanges();
                return RedirectToAction("Login");
            }
            else
            {
                return View();
            }
               
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(string Name, string Password)
        {
            if (ModelState.IsValid)
            {


                var naame = (from x in _context.users
                             where x.Name == Name && x.Password == Password
                             select x).FirstOrDefault();
                username = naame.Id;
                if (naame != null)
                {
                    return RedirectToAction("HomePage", "Products");
                }
                else
                {
                    return Content("go2");
                }
            }
            return View();
        }

    }
}
