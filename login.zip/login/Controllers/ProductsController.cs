﻿using login.data;
using login.Models;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System.Data.Common;

namespace login.Controllers
{
    public class ProductsController : Controller
    {
        private readonly Context _context;
        private IWebHostEnvironment _environment;  

        public ProductsController(Context context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _environment = webHostEnvironment;
        }

        public IActionResult HomePage()
        {

            var pp = _context.products.Where(x => x.UserID == HomeController.username).ToList();
            return View(pp);
            
        }
        [HttpGet]
        public IActionResult ViewProducts()
        {
            var items = _context.products.Where(x=>x.UserID == HomeController.username)
                .ToList();
            return View(items);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        public async Task<IActionResult> Create(Product product, IFormFile formFile)
        {
            var id = HomeController.username;
            if (formFile.Length > 0 && formFile is not null)
            {
                var fileName = product.Name.Trim().Replace(" ", "_");
                var ext = Path.GetExtension(formFile.FileName);
                var path = $"{fileName}{ext}";
                var file = Path.Combine($"wwwroot/images", path);

                using (var stream = new FileStream(file, FileMode.Create))
                {
                    await formFile.CopyToAsync(stream);
                }
                product.ImageURL = $"/images/{path}";
                product.UserID = id;
               
            }
            _context.products.Add(product);
            await _context.SaveChangesAsync();
            return RedirectToAction("ViewProducts");
        }


        [HttpGet]
        public IActionResult Edit(int id)
        {
            var product = _context.products.Find(id);
            if (product == null) { return NotFound(); }
            return View(product);
        }

        [HttpPost]
        public IActionResult Edit(Product product)
        {
            var userid = HomeController.username;
            product.UserID = userid;
            var productID = _context.products.Find(product.Id);
            if (productID == null)
            {
                return NotFound();
            }
            productID.Name = product.Name;
            productID.Description = product.Description;
            productID.Price = product.Price;
            productID.UserID = product.UserID;

            _context.SaveChanges();
            return RedirectToAction("ViewProducts");
        }

        public IActionResult Delete(int id)
        {
            var del = _context.products.Find(id);
            _context.products.Remove(del);
            _context.SaveChanges();
            return RedirectToAction("ViewProducts");        
        }
        public IActionResult Details(int id)
        {
            var pro = _context.products.Find(id);
            if (pro == null)
            {
                return NotFound();
            }
            return View(pro);        
        }
    }
}
