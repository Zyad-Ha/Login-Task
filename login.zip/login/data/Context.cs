﻿using login.Models;
using Microsoft.EntityFrameworkCore;

namespace login.data
{
    public class Context:DbContext
    {
        public Context(DbContextOptions options): base(options) { }

        public DbSet<User> users { get; set; }
        public DbSet<Product> products { get; set; }


    }
}
